import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner input;
        input = new Scanner(System.in);

        boolean exit;
        exit = false;
        int scelta;
        int nMacchine;

        String plate;
        String model;
        String owner;


        GestioneAutomobili deposito1 = new GestioneAutomobili();

        while(!exit){
            System.out.println("0. esci dal programma");
            System.out.println("1. riempi gli array");
            System.out.println("2. elimina macchina");
            System.out.println("3. ricerca macchina");
            System.out.println("4. metodo toString");
            System.out.println("5. Modifica propietario data la targa");
            System.out.println("6. Conta modelli");


            do{
                System.out.print("Inserisci la scelta:  ");
                scelta = input.nextInt();
            }while(scelta<0 && scelta >3);

            switch(scelta){
                case 0:
                    System.out.print("Arrivedeci");
                    exit = true;
                    break;

                case 1:
                    input = new Scanner(System.in);
                    do{
                        System.out.print("Quante macchine vuoi inserire:  ");
                        input = new Scanner(System.in);

                        nMacchine = input.nextInt();
                    }while(nMacchine<1 && nMacchine>100);

                    int i;
                    int contaMacchine;
                    contaMacchine = 1;
                    for(i = 0; i<nMacchine; i++){

                        input = new Scanner(System.in);
                        System.out.println("Inserisci la targa della "+contaMacchine+ "^a macchina");
                        plate = input.nextLine();

                        input = new Scanner(System.in);
                        System.out.println("Inserisci il modello della "+contaMacchine+ "^a macchina");
                        model = input.nextLine();

                        input = new Scanner(System.in);
                        System.out.println("Inserisci il propietario della "+contaMacchine+ "^a macchina");
                        owner = input.nextLine();

                        System.out.println(deposito1.inserimento(nMacchine,plate, model, owner, i));

                        contaMacchine++;

                    }
                    break;

                case 2:
                    input = new Scanner(System.in);

                    System.out.print("Inserisci la targa da eliminare:  ");
                    plate = input.nextLine();
                    System.out.println("La targa "+ plate + "è stata eliminata :  "+ deposito1.elimina(plate));
                    break;

                case 3:
                    input = new Scanner(System.in);
                    System.out.print("Inserisci il nome del propietario:  ");
                    owner = input.nextLine();
                    System.out.println(deposito1.ricerca(owner));
                    break;

                case 4:
                    System.out.println("Gli array sono: ");
                    System.out.println(deposito1.toString());
                    break;

                case 5:
                    input = new Scanner(System.in);
                    System.out.println("Inserisci la targa della macchina da modificare");
                    plate = input.nextLine();

                    input = new Scanner(System.in);
                    System.out.println("Inserisci il nuovo propietario");
                    owner = input.nextLine();
                    System.out.println(deposito1.modifica(plate,owner));
                    break;

                case 6:
                    input = new Scanner(System.in);
                    System.out.println("Inserisci il modello da contare ");
                    model = input.nextLine();

                    System.out.println("I modelli uguali sono : "+deposito1.contaModelli(model));
                    break;


            }

            System.out.println("");
            System.out.println("");
            System.out.println("");

        }


    }
}