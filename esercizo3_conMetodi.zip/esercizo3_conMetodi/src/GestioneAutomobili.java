public class GestioneAutomobili {
    private String targa[];
    private String modello[];
    private String propietario[];

    private int dimensioneLogica;

    //costruttore
    GestioneAutomobili(){
        targa = new String[100];
        modello = new String[100];
        propietario = new String[100];
        dimensioneLogica = 0;
        azzeraArray();
    }

    public int inserimento(int dim, String plate, String model, String owner, int index){
        dimensioneLogica ++;
        int inserimento;
        inserimento = 1;
        boolean inserita = false;
        int i = 0;

        if(controlloPieno()){
            inserimento = -1;
        }else{
            if(controlloTagra(plate) == false ){
                while(!inserita && i< 100){
                    if(targa[i].equals("")){
                        targa[i] = plate;
                        modello[i] = model;
                        propietario[i] = owner;
                        inserita = true;
                    }
                    i++;
                }

            }else{
                inserimento = 0;
            }
        }
        return inserimento;

    }

    private boolean controlloTagra(String plate){
        boolean trovata;
        trovata = false;
        int i;
        i = 0;
        while(i< dimensioneLogica && trovata == false){
            trovata = targa[i].equals(plate);
            i++;
        }
        return trovata;
    }

    private boolean controlloPieno(){
        boolean pieno;
        pieno = false;
        int i;
        i = 0;

        if(dimensioneLogica >=100){
            pieno = true;
        }

        return pieno;
    }

    public void azzeraArray(){
        int i;
        for(i = 0;i <100; i++){
            targa[i]= "";
            modello[i]= "";
            propietario[i]= "";
        }
    }

    public boolean elimina(String plate){
        boolean trovata, eliminata;
        trovata = false;
        eliminata = false;
        int i;
        i = 0;
        while(i< dimensioneLogica ){
            trovata = targa[i].equals(plate);
            if (trovata){
                targa[i] = "";
                modello[i] = "";
                propietario[i] = "";
                shiftSinistra(i);
                eliminata = true;
            }
            i++;
        }
        return eliminata;
    }

    public String ricerca(String owner){
        String stringa;
        stringa = "";
        int i;
        for(i = 0; i< dimensioneLogica;i++){
            if(propietario[i].equals(owner)) {
                stringa = stringa + " -- " + targa[i] + "/" + modello[i] + "/" + propietario[i];
            }
        }
        return stringa;
    }

    @Override
    public String toString(){
        int i;
        String stringa;
        stringa = "";
        for(i=0; i<100;i++){
            stringa = stringa+targa[i]+"/"+modello[i]+"/"+propietario[i]+"\n";
        }
        return stringa;
    }

    private void shiftSinistra(int partenza){
        int i;
        for(i= partenza; i<(100-partenza);i++){
            targa[i]= targa[i+1];
            modello[i]= modello[i+1];
            propietario[i]= propietario[i+1];
        }
    }

    public String modifica(String plate, String owner){
        if(controlloTagra(plate)){
            boolean modificata = false;
            int i = 0;
            while(!modificata && i< dimensioneLogica){
                if(targa[i].equals(plate)) {
                    propietario[i] = owner;
                    modificata = true;
                }
                i++;
            }
            return "Modifica effettuata con successo";
        }else{
            return "Modifica non effettuata con successo";
        }
    }

    public int contaModelli(String model){
        int i;
        int nModelli = 0;
        for(i = 0; i< dimensioneLogica;i++){
            if(modello[i].equals(model)){
                nModelli++;
            }
        }
        return nModelli;
    }



}
